<?php

    $file = file_get_contents("./index.html");

    if(isset($_POST["hash"])){
        $output = shell_exec("echo -n ".$_POST["hash"]."| md5sum | awk '{print $1}'"); //echo -n Welcome | md5sum | awk '{print $1}'
        $file = sprintf($file,$output);
        echo $file;
    }
    else{
        $file = sprintf($file,"");
        echo $file;
    }
?>